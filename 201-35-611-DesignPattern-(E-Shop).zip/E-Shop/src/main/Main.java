package main;

import application.*;
import bankApi.Bkash;
import bankApi.Nagad;
import bankApi.Rocket;

public class Main {

	public static void main (String[] args) {
		IntegrationClass app = IntegrationClass.getObject();
		Bkash bkash = Bkash.getBkash();
		bkash.setBalance(2000);
		bkash.setCharge(18.50);
		
		Nagad nagad = Nagad.getNagad();
		nagad.setBalance(3000);
		nagad.setCharge(14.99);
		
		Rocket rocket = Rocket.getRocket();
		rocket.setBalance(3000);
		rocket.setCharge(14.50);
		
		Customer customer = app.customer;
		
		Seller seller1 = new Seller();
		seller1.addProduct("Shampoo", 200);
		seller1.addProduct("Soap",50);
		seller1.addProduct("Hair condisioner", 220);
		seller1.addProduct("Face Cream",100);
		seller1.addProduct("Face Wash",120);
		
		Seller seller2 = new Seller();
		seller2.addProduct("mouse",650);
		seller2.addProduct("Keybord A4T",890);
		seller2.addProduct("HeadPhone", 1290);
		seller2.addProduct("PenDrive", 605);
		seller2.addProduct("SSD 12GB",2130);
		
		Seller seller3 = new Seller();
		seller3.addProduct("Pizza 6", 650);
		seller3.addProduct("Psta", 390);
		seller3.addProduct("Burger", 240);
		seller3.addProduct("Sandues",160);
		seller3.addProduct("Fride Rice",210);
		app.addSeller(seller1);
		app.addSeller(seller2);
		app.addSeller(seller3);
		app.updateProducts();
		
		
		
		customer. setName("Md. Ashiqur Rahman");
		customer.setEmail("ashiq611@gmail.com");
		customer.setAdress("YKSH-1,Daffodil Smart City");
		customer.setContact("01238473334");
		customer.displayUserData();
		
		app.showProducts();
		app.shop();
		customer.getCart().displayAllOrder();
		bkash.displayAccountInfo();
		nagad.displayAccountInfo();
		rocket.displayAccountInfo();
		customer.getCart().makePayment();
		
		

	}

}
