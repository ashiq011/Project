package bankApi;

public interface Bank {
	public double makePayment(double bill);
	public void displayAccountInfo();
}
